#define _CRT_SECURE_NO_WARNINGS // Beh�vs f�r vissa funktioner i visual studio
#include "HashTable.h"
#include "Bucket.h"
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>

#define UNUSED 0	// Anv�nds f�r att markera en ledig plats i Hashtabellen


/* Denna funktion tar en nyckel och returnerar ett hash-index
dvs ett index till arrayen som �r Hashtabellen */
static int hash(Key key, int tablesize)
{
	return -1; // Ers�tt med ett index
}

HashTable createHashTable(unsigned int size)
{
	// Dessa tv� rader �r bara tillf�r att labskelettet ska kompilera. Ta bort dessa n�r du skriver funktionen.
	HashTable htable = { 0 };
	return htable;
}

void insertElement(HashTable* htable, const Key key, const Value value)
{
	// Postcondition: det finns ett element f�r key i tabellen (anv�nd lookup() f�r att verifiera)
}

void deleteElement(HashTable* htable, const Key key)
{
	// Postcondition: inget element med key finns i tabellen (anv�nd loookup() f�r att verifiera)
}

const Value* lookup(const HashTable* htable, const Key key)
{
	return NULL; // Ers�tt med r�tt v�rde
}

unsigned int getSize(const HashTable* htable)
{
	return 0; // Ers�tt med r�tt v�rde
}

void freeHashTable(HashTable* htable)
{
	// Postcondition: hashtabellen har storlek 0
}

void printHashTable(const HashTable* htable)
{
	// Tips: anv�nd printPerson() i Person.h f�r att skriva ut en person
}
